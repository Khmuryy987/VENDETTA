import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Plus, Clock, DollarSign, Trash2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import SnowEffect from '@/components/SnowEffect';
import ChristmasDecorations from '@/components/ChristmasDecorations';
import Navbar from '@/components/Navbar';

interface SalaryEntry {
  id: number;
  name: string;
  card: string;
  points: number;
  salary: number;
}

const mockSalaryData: SalaryEntry[] = [
  { id: 1, name: 'Кейн Кайрон', card: '187300', points: 208, salary: 2040000 },
  { id: 2, name: 'Картер Кайрон', card: '189610', points: 140, salary: 1700000 },
  { id: 3, name: 'Олександр Циган', card: '174112', points: 93, salary: 1465000 },
  { id: 4, name: 'Владислав Янукович', card: '185362', points: 25, salary: 125000 },
  { id: 5, name: 'Лекс Хантер', card: '199108', points: 20, salary: 100000 },
  { id: 6, name: 'Гена Кайрон', card: '193072', points: 20, salary: 100000 },
  { id: 7, name: 'Тимур Кайрон', card: '193138', points: 10, salary: 0 },
];

const taskOptions = [
  { label: 'Закладки (+2 балів)', value: 2 },
  { label: 'Графіті (+2 балів за шт.)', value: 2 },
  { label: 'Завдання бункера (+10 балів)', value: 10 },
  { label: 'Замовлення картелю (+10 балів)', value: 10 },
  { label: 'Вбивство ворожого клановця (+10 балів)', value: 10 },
  { label: 'Повітряний груз (+20 балів)', value: 20 },
  { label: 'РП / БП / ГРП (+15 балів)', value: 15 },
  { label: 'Бізвар (+20 балів)', value: 20 },
  { label: 'Страйк (+8 балів)', value: 8 },
  { label: 'Від лідера/модера (+5 балів)', value: 5 },
  { label: 'Перемога в МП (клан | адмін) (+50 балів)', value: 50 },
];

const Salary = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnlyMe, setShowOnlyMe] = useState(false);
  const [selectedTask, setSelectedTask] = useState('');
  const [proofLink, setProofLink] = useState('');

  const totalSalary = mockSalaryData.reduce((acc, entry) => acc + entry.salary, 0);

  const filteredData = mockSalaryData.filter(entry =>
    entry.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.card.includes(searchQuery)
  );

  const handleAddPoints = () => {
    if (!selectedTask) {
      toast({
        title: "Помилка",
        description: "Оберіть задачу",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Бали додано!",
      description: "Задачу успішно зараховано",
    });
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <SnowEffect />
      <ChristmasDecorations />
      <Navbar isLoggedIn userRole="leader" />
      
      <main className="relative z-10 pt-24 pb-12 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="font-display text-3xl font-bold mb-2">
              <span className="text-gradient-gold">Таблиця активності</span>
            </h1>
          </div>
          
          {/* Search & Filters */}
          <div className="glass-card p-4 mb-6">
            <div className="flex flex-col md:flex-row items-center gap-4">
              <div className="flex items-center gap-3">
                <Button variant="secondary" size="icon">
                  <Plus className="h-5 w-5" />
                </Button>
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    placeholder="Пошук..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-background/50"
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showOnlyMe}
                    onChange={(e) => setShowOnlyMe(e.target.checked)}
                    className="rounded border-border"
                  />
                  <span className="text-sm text-muted-foreground">Тільки Я</span>
                </label>
                
                <Button variant="destructive" size="icon">
                  <span className="text-lg">❌</span>
                </Button>
                <Button variant="default" size="icon">
                  <span className="text-lg">✅</span>
                </Button>
                <Button variant="success" size="icon">
                  <span className="text-lg">✅</span>
                </Button>
              </div>
              
              <div className="flex items-center gap-2 ml-auto">
                <DollarSign className="h-5 w-5 text-success" />
                <span className="font-display text-xl font-bold text-success">
                  {totalSalary.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
          
          {/* Salary Table */}
          <div className="glass-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-secondary/50">
                    <th className="text-left p-4 text-muted-foreground font-semibold">Ім'я</th>
                    <th className="text-left p-4 text-muted-foreground font-semibold">Карта</th>
                    <th className="text-center p-4 text-muted-foreground font-semibold">Бали</th>
                    <th className="text-center p-4 text-muted-foreground font-semibold">Зарплата</th>
                    <th className="text-center p-4 text-muted-foreground font-semibold">Дії</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.map((entry, index) => (
                    <tr 
                      key={entry.id}
                      className="border-b border-border/50 hover:bg-secondary/30 transition-colors animate-fade-in"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <td className="p-4">
                        <span className="font-medium text-primary">
                          {entry.name}
                        </span>
                      </td>
                      <td className="p-4 font-mono text-muted-foreground">{entry.card}</td>
                      <td className="p-4 text-center">
                        <span className="inline-flex items-center justify-center px-3 py-1 rounded-full bg-success/20 text-success font-bold">
                          {entry.points}
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <span className="inline-flex items-center justify-center px-3 py-1 rounded-full bg-primary/20 text-primary font-bold">
                            {entry.salary.toLocaleString()}
                          </span>
                          <DollarSign className="h-4 w-4 text-primary" />
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="success" size="icon" className="h-8 w-8">
                                <Plus className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="glass-card border-primary">
                              <DialogHeader>
                                <DialogTitle className="font-display text-gradient-gold">
                                  Додати задачу
                                </DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4 pt-4">
                                <div>
                                  <label className="text-sm text-muted-foreground mb-2 block">Що зробив</label>
                                  <Select value={selectedTask} onValueChange={setSelectedTask}>
                                    <SelectTrigger className="bg-background/50">
                                      <SelectValue placeholder="Оберіть задачу" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {taskOptions.map((task) => (
                                        <SelectItem key={task.label} value={task.label}>
                                          {task.label}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div>
                                  <label className="text-sm text-muted-foreground mb-2 block">Докази</label>
                                  <div className="flex gap-2">
                                    <Input
                                      placeholder="Посилання на доказ"
                                      value={proofLink}
                                      onChange={(e) => setProofLink(e.target.value)}
                                      className="bg-background/50"
                                    />
                                    <Button variant="default" size="sm">
                                      Postimages
                                    </Button>
                                  </div>
                                </div>
                                <div className="flex gap-3 pt-4">
                                  <Button variant="outline" className="flex-1">
                                    Скасувати
                                  </Button>
                                  <Button variant="hero" className="flex-1" onClick={handleAddPoints}>
                                    Додати
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          
                          <Button variant="secondary" size="icon" className="h-8 w-8">
                            <Clock className="h-4 w-4" />
                          </Button>
                          <Button variant="destructive" size="icon" className="h-8 w-8">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Salary;
