import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import SnowEffect from '@/components/SnowEffect';
import ChristmasDecorations from '@/components/ChristmasDecorations';
import Navbar from '@/components/Navbar';

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Вхід виконано!",
        description: "Ласкаво просимо назад до VENDETTA",
      });
      navigate('/members');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <SnowEffect />
      <ChristmasDecorations />
      <Navbar />
      
      <main className="relative z-10 flex items-center justify-center min-h-screen px-4 pt-20">
        <div className="w-full max-w-md animate-fade-in">
          <div className="glass-card p-8 glow-border-gold">
            <h1 className="font-display text-2xl font-bold text-center mb-8">
              <span className="text-gradient-gold">Вхід</span>
            </h1>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Input
                  type="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="bg-background/50"
                />
              </div>
              
              <div className="space-y-2">
                <Input
                  type="password"
                  placeholder="Пароль"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                  className="bg-background/50"
                />
              </div>
              
              <Button
                type="submit"
                variant="hero"
                size="lg"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? 'Вхід...' : 'Увійти'}
              </Button>
            </form>
            
            <p className="text-center text-muted-foreground mt-6">
              Ще не маєте акаунта?{' '}
              <Link to="/register" className="text-primary hover:underline font-semibold">
                Зареєструватися
              </Link>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Login;
