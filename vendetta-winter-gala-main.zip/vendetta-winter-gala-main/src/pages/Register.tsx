import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import SnowEffect from '@/components/SnowEffect';
import ChristmasDecorations from '@/components/ChristmasDecorations';
import Navbar from '@/components/Navbar';

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    gameNick: '',
    discord: '',
    card: '',
    recruiter: '',
    email: '',
    password: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.card.length !== 6 || !/^\d+$/.test(formData.card)) {
      toast({
        title: "Помилка",
        description: "Карта повинна містити рівно 6 цифр",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate registration
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Заявку надіслано!",
        description: "Ваша заявка очікує розгляду Лідером",
      });
      navigate('/');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <SnowEffect />
      <ChristmasDecorations />
      <Navbar />
      
      <main className="relative z-10 flex items-center justify-center min-h-screen px-4 py-24">
        <div className="w-full max-w-lg animate-fade-in">
          <div className="glass-card p-8 glow-border-gold">
            <h1 className="font-display text-2xl font-bold text-center mb-2">
              <span className="text-gradient-gold">Реєстрація</span>
            </h1>
            <p className="text-muted-foreground text-center text-sm mb-8">
              Заповніть форму для вступу в клан VENDETTA
            </p>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Input
                  placeholder="Ім'я"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  required
                  className="bg-background/50"
                />
                <Input
                  placeholder="Прізвище"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  required
                  className="bg-background/50"
                />
              </div>
              
              <Input
                placeholder="Ваш ігровий нік"
                value={formData.gameNick}
                onChange={(e) => setFormData({ ...formData, gameNick: e.target.value })}
                required
                className="bg-background/50"
              />
              
              <Input
                placeholder="Ваш Discord"
                value={formData.discord}
                onChange={(e) => setFormData({ ...formData, discord: e.target.value })}
                required
                className="bg-background/50"
              />
              
              <Input
                placeholder="Ваша карта (6 цифр)"
                value={formData.card}
                onChange={(e) => setFormData({ ...formData, card: e.target.value.slice(0, 6) })}
                required
                maxLength={6}
                className="bg-background/50"
              />
              
              <Input
                placeholder="Хто приймав (нік рекрутера)"
                value={formData.recruiter}
                onChange={(e) => setFormData({ ...formData, recruiter: e.target.value })}
                required
                className="bg-background/50"
              />
              
              <div className="border-t border-border my-6 pt-4">
                <p className="text-muted-foreground text-xs mb-4">Дані для входу</p>
                
                <Input
                  type="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="bg-background/50 mb-4"
                />
                
                <Input
                  type="password"
                  placeholder="Пароль"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                  className="bg-background/50"
                />
              </div>
              
              <div className="bg-accent/10 border border-accent/30 rounded-lg p-3 text-sm">
                <p className="text-accent font-semibold">⚠️ Важливо!</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Обов'язково збережіть email та пароль для входу! Відновлення доступу неможливе.
                </p>
              </div>
              
              <Button
                type="submit"
                variant="hero"
                size="lg"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? 'Надсилання...' : 'Надіслати заявку'}
              </Button>
            </form>
            
            <p className="text-center text-muted-foreground mt-6 text-sm">
              Вже є акаунт?{' '}
              <Link to="/login" className="text-primary hover:underline font-semibold">
                Увійти
              </Link>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Register;
