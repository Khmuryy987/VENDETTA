import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import SnowEffect from '@/components/SnowEffect';
import ChristmasDecorations from '@/components/ChristmasDecorations';
import Navbar from '@/components/Navbar';

const Index = () => {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <SnowEffect />
      <ChristmasDecorations />
      <Navbar />
      
      {/* Hero Section */}
      <main className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        <div className="text-center space-y-8 animate-fade-in">
          {/* Logo */}
          <div className="flex items-center justify-center gap-4 mb-4">
            <span className="text-6xl animate-float">🔥</span>
          </div>
          
          {/* Title */}
          <h1 className="font-display text-5xl md:text-7xl font-black tracking-wider">
            <span className="text-foreground">Ласкаво просимо до </span>
            <span className="text-gradient-gold">VENDETTA</span>
          </h1>
          
          {/* Subtitle */}
          <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto">
            Офіційний сайт клану. Приєднуйся до найсильнішої команди та стань частиною легенди!
          </p>
          
          {/* Decorative Star */}
          <div className="flex justify-center my-8">
            <span className="text-5xl animate-glow-pulse">⭐</span>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/login">
              <Button variant="heroOutline" size="xl" className="min-w-[160px]">
                Вхід
              </Button>
            </Link>
            <Link to="/register">
              <Button variant="hero" size="xl" className="min-w-[160px]">
                Реєстрація
              </Button>
            </Link>
          </div>
          
          {/* Stats */}
          <div className="flex items-center justify-center gap-8 mt-12 flex-wrap">
            <div className="glass-card px-6 py-4 text-center glow-border-gold">
              <div className="font-display text-3xl font-bold text-primary">50+</div>
              <div className="text-muted-foreground text-sm">Учасників</div>
            </div>
            <div className="glass-card px-6 py-4 text-center glow-border-red">
              <div className="font-display text-3xl font-bold text-accent">🏆</div>
              <div className="text-muted-foreground text-sm">Топ клан</div>
            </div>
            <div className="glass-card px-6 py-4 text-center glow-border-green">
              <div className="font-display text-3xl font-bold text-success">24/7</div>
              <div className="text-muted-foreground text-sm">Активність</div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer decorations */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-10">
        <span className="text-4xl animate-float" style={{ animationDelay: '0.5s' }}>🎅</span>
      </div>
    </div>
  );
};

export default Index;
