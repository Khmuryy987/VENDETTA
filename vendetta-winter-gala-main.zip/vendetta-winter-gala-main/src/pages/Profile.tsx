import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw, Camera, User, Shield, CreditCard, Trophy, Clock, AlertTriangle } from 'lucide-react';
import SnowEffect from '@/components/SnowEffect';
import ChristmasDecorations from '@/components/ChristmasDecorations';
import Navbar from '@/components/Navbar';

const Profile = () => {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const profileData = {
    name: 'Юліана Блейк',
    role: 'ГАРП',
    gameId: '129016',
    card: '206830',
    punishments: 0,
    level: 'LVL',
    daysInClan: 45,
    avatar: null,
  };

  const stats = [
    { icon: Shield, label: 'Роль', value: profileData.role, color: 'glow-border-gold' },
    { icon: User, label: 'Ігровий ID', value: profileData.gameId, color: 'glow-border-green' },
    { icon: CreditCard, label: 'Карта', value: profileData.card, color: 'glow-border-gold' },
    { icon: AlertTriangle, label: 'Покарання', value: profileData.punishments, color: 'glow-border-red' },
    { icon: Trophy, label: 'Ігровий рівень', value: `🎄 ${profileData.level}`, color: 'glow-border-purple' },
    { icon: Clock, label: 'Кількість днів у клані', value: profileData.daysInClan, color: 'glow-border-gold' },
  ];

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <SnowEffect />
      <ChristmasDecorations />
      <Navbar isLoggedIn userRole="member" />
      
      <main className="relative z-10 pt-24 pb-12 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="grid md:grid-cols-3 gap-6">
            {/* Profile Card */}
            <div className="glass-card p-6 glow-border-gold animate-fade-in">
              <div className="text-center">
                <h2 className="font-display text-xl font-bold text-primary mb-6">
                  {profileData.name}
                </h2>
                
                {/* Avatar */}
                <div className="relative inline-block mb-4">
                  <div className="w-32 h-32 rounded-full border-4 border-primary bg-secondary flex items-center justify-center overflow-hidden">
                    {profileData.avatar ? (
                      <img src={profileData.avatar} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-16 h-16 text-muted-foreground" />
                    )}
                  </div>
                  
                  {/* Status indicators */}
                  <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-success flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                      <span className="text-xs">🟢</span>
                    </div>
                    <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                      <RefreshCw className="w-3 h-3" />
                    </div>
                  </div>
                </div>
                
                {/* Actions */}
                <div className="flex justify-center gap-2 mt-4">
                  <Button variant="secondary" size="sm">
                    <Camera className="w-4 h-4 mr-1" />
                    Змінити фото
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleRefresh}
                    disabled={isRefreshing}
                  >
                    <RefreshCw className={`w-4 h-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
                    Оновити
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Stats Grid */}
            <div className="md:col-span-2 grid grid-cols-2 md:grid-cols-3 gap-4">
              {stats.map((stat, index) => (
                <div 
                  key={stat.label}
                  className={`glass-card p-4 ${stat.color} animate-fade-in`}
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex flex-col items-center text-center">
                    <stat.icon className="w-6 h-6 text-primary mb-2" />
                    <span className="text-muted-foreground text-xs mb-1">{stat.label}</span>
                    <span className="font-display text-xl font-bold text-foreground">
                      {stat.value}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Activity Section */}
          <div className="glass-card p-6 mt-6 animate-fade-in" style={{ animationDelay: '400ms' }}>
            <h3 className="font-display text-lg font-bold text-primary mb-4">
              Остання активність
            </h3>
            <div className="text-center py-8 text-muted-foreground">
              <p>Поки немає записів про активність</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Profile;
