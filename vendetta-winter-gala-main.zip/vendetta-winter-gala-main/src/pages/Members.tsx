import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import SnowEffect from '@/components/SnowEffect';
import ChristmasDecorations from '@/components/ChristmasDecorations';
import Navbar from '@/components/Navbar';

interface Member {
  id: number;
  name: string;
  role: 'leader' | 'moderator' | 'support' | 'member';
visibleRole: string;
  oderId: string;
  card: string;
  discord: string;
  email: string;
  avatar?: string;
}

const mockMembers: Member[] = [
  { id: 1, name: 'Ярослав Кайрон', role: 'leader', visibleRole: 'ЛІДЕР', oderId: '69965', card: '126010', discord: 'oracar', email: 'yaroslav@mail.com' },
  { id: 2, name: 'Конор Кайрон 🎅', role: 'leader', visibleRole: 'ЛІДЕР', oderId: '101435', card: '160672', discord: 'not_found...', email: 'conor@mail.com' },
  { id: 3, name: 'Кенли Кайрон', role: 'moderator', visibleRole: 'МОДЕР', oderId: '109191', card: '176446', discord: 'miron0181...', email: 'bratik@mail.com' },
  { id: 4, name: 'Федір Кайрон', role: 'moderator', visibleRole: 'МОДЕР', oderId: '117839', card: '185116', discord: '_demossss_', email: 'fedor@mail.com' },
  { id: 5, name: 'Кола Кайрон', role: 'support', visibleRole: 'SUPPORT', oderId: '120885', card: '189544', discord: 'kola_2660', email: 'kola@mail.com' },
  { id: 6, name: 'Мурза Кайрон', role: 'support', visibleRole: 'SUPPORT', oderId: '118721', card: '186592', discord: 'bogdan11...', email: 'bohdan@mail.com' },
  { id: 7, name: 'Нікітос Кайрон', role: 'support', visibleRole: 'SUPPORT', oderId: '14350', card: '117796', discord: 'hardplayer1', email: 'nikita@mail.com' },
  { id: 8, name: 'Владислав Янукович', role: 'member', visibleRole: 'ГАРП', oderId: '117893', card: '185362', discord: 'vlados_9455', email: 'vladislav@mail.com' },
  { id: 9, name: 'Лекс Хантер', role: 'member', visibleRole: 'ГАРП', oderId: '125547', card: '199108', discord: 'mkalxs9540', email: 'leks@mail.com' },
  { id: 10, name: 'Гена Кайрон', role: 'member', visibleRole: 'ГАРП', oderId: '122944', card: '193072', discord: '@genuch_...', email: 'genus@mail.com' },
];

const roleFilters = ['Всі', 'СС', 'КАДРОВИКИ', 'ТСС', 'ГАРП', 'НП', 'КАІТ'];

const getRoleClass = (role: string) => {
  switch (role) {
    case 'leader': return 'role-leader';
    case 'moderator': return 'role-moderator';
    case 'support': return 'role-support';
    default: return 'bg-blue-600 text-white';
  }
};

const Members = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('Всі');

  const filteredMembers = mockMembers.filter(member =>
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.discord.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.card.includes(searchQuery)
  );

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <SnowEffect />
      <ChristmasDecorations />
      <Navbar isLoggedIn userRole="leader" />
      
      <main className="relative z-10 pt-24 pb-12 px-4">
        <div className="container mx-auto max-w-7xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-3xl font-bold mb-2">
              <span className="text-gradient-gold">Учасники VENDETTA</span>
            </h1>
            <p className="text-muted-foreground">
              <span className="text-primary font-semibold">{mockMembers.length}</span> учасників у клані
            </p>
          </div>
          
          {/* Search & Filters */}
          <div className="glass-card p-4 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Пошук за ніком, діскордом, картою або ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-background/50"
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                {roleFilters.map((filter) => (
                  <Button
                    key={filter}
                    variant={activeFilter === filter ? 'default' : 'secondary'}
                    size="sm"
                    onClick={() => setActiveFilter(filter)}
                  >
                    {filter}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          
          {/* Members Table */}
          <div className="glass-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-secondary/50">
                    <th className="text-left p-4 text-muted-foreground font-semibold">#</th>
                    <th className="text-left p-4 text-muted-foreground font-semibold">Нік</th>
                    <th className="text-left p-4 text-muted-foreground font-semibold">Роль</th>
                    <th className="text-left p-4 text-muted-foreground font-semibold">ID</th>
                    <th className="text-left p-4 text-muted-foreground font-semibold">Карта</th>
                    <th className="text-left p-4 text-muted-foreground font-semibold">Discord</th>
                    <th className="text-left p-4 text-muted-foreground font-semibold">Пошта</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredMembers.map((member, index) => (
                    <tr 
                      key={member.id}
                      className="border-b border-border/50 hover:bg-secondary/30 transition-colors cursor-pointer animate-fade-in"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <td className="p-4 text-muted-foreground">{index + 1}</td>
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                            <span className="text-lg">👤</span>
                          </div>
                          <span className="font-medium text-primary hover:text-primary/80 transition-colors">
                            {member.name}
                          </span>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`role-badge ${getRoleClass(member.role)}`}>
                          {member.visibleRole}
                        </span>
                      </td>
                      <td className="p-4 font-mono text-muted-foreground">{member.oderId}</td>
                      <td className="p-4 font-mono">{member.card}</td>
                      <td className="p-4 text-muted-foreground">{member.discord}</td>
                      <td className="p-4 text-muted-foreground text-sm">{member.email}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Members;
