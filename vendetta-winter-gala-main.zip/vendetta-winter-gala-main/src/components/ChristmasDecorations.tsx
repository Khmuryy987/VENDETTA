const ChristmasDecorations = () => {
  const decorations = [
    { emoji: '🎄', top: '5%', left: '3%', size: 60, delay: 0 },
    { emoji: '🎁', top: '15%', right: '5%', size: 50, delay: 1 },
    { emoji: '⭐', top: '40%', left: '8%', size: 40, delay: 0.5 },
    { emoji: '🎅', top: '70%', right: '3%', size: 55, delay: 1.5 },
    { emoji: '❄️', top: '80%', left: '5%', size: 35, delay: 2 },
    { emoji: '🔔', top: '25%', right: '8%', size: 40, delay: 0.8 },
    { emoji: '🍭', bottom: '10%', right: '10%', size: 45, delay: 1.2 },
    { emoji: '🎀', top: '55%', left: '4%', size: 38, delay: 1.8 },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {decorations.map((deco, index) => (
        <div
          key={index}
          className="absolute animate-float"
          style={{
            top: deco.top,
            left: deco.left,
            right: deco.right,
            bottom: deco.bottom,
            fontSize: `${deco.size}px`,
            animationDelay: `${deco.delay}s`,
            filter: 'drop-shadow(0 0 10px rgba(255,200,0,0.3))',
          }}
        >
          {deco.emoji}
        </div>
      ))}
    </div>
  );
};

export default ChristmasDecorations;
