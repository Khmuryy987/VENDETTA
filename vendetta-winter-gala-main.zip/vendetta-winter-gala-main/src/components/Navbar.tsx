import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Users, Settings, User, LogOut, Bell } from 'lucide-react';

interface NavbarProps {
  isLoggedIn?: boolean;
  userRole?: 'leader' | 'moderator' | 'support' | 'member';
}

const Navbar = ({ isLoggedIn = false, userRole }: NavbarProps) => {
  const location = useLocation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <span className="text-2xl">🔥</span>
          <span className="font-display text-xl font-bold text-gradient-gold">
            VENDETTA
          </span>
          <span className="text-xl">🎄</span>
        </Link>

        {/* Navigation Links */}
        {isLoggedIn && (
          <div className="hidden md:flex items-center gap-2">
            <Link to="/members">
              <Button
                variant={location.pathname === '/members' ? 'default' : 'ghost'}
                size="icon"
                className="relative"
              >
                <Users className="h-5 w-5" />
              </Button>
            </Link>
            
            {(userRole === 'leader' || userRole === 'moderator') && (
              <Link to="/admin">
                <Button
                  variant={location.pathname === '/admin' ? 'default' : 'ghost'}
                  size="icon"
                >
                  <Settings className="h-5 w-5" />
                </Button>
              </Link>
            )}
          </div>
        )}

        {/* Right Side */}
        <div className="flex items-center gap-3">
          {isLoggedIn ? (
            <>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-accent rounded-full text-[10px] flex items-center justify-center">
                  3
                </span>
              </Button>
              <Link to="/profile">
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </Link>
              <Button variant="outline" size="icon">
                <LogOut className="h-5 w-5" />
              </Button>
            </>
          ) : (
            <>
              <Link to="/login">
                <Button variant="heroOutline" size="sm">
                  Вхід
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="hero" size="sm">
                  Реєстрація
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
